public interface Calculos {
    public void menu();
}
